function createAndStyleElement(tag, classes, innerHTML = '') {
  const el = document.createElement(tag);
  el.className = classes;
  el.innerHTML = innerHTML;
  return el;
}

function createDigitalBusinessCard() {
  const body = document.body;
  body.className = 'min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 text-slate-800 dark:from-slate-900 dark:to-slate-950 dark:text-slate-100 transition-colors';

  const wrapper = createAndStyleElement('div', 'mx-auto max-w-5xl px-4 py-10 md:py-14');

  const header = createAndStyleElement('div', 'flex items-center justify-between mb-6');
  header.appendChild(createAndStyleElement('div', 'text-sm opacity-80', 'Digital Business Card'));
  
  const headerBtns = createAndStyleElement('div', 'flex items-center gap-2');
  const vcardBtn = createAndStyleElement('button', 'rounded-2xl border border-slate-300 dark:border-slate-700 px-3 py-1.5 text-sm hover:shadow-soft transition', 'Download vCard');
  vcardBtn.id = 'vcardBtn';
  const themeToggle = createAndStyleElement('button', 'rounded-2xl border border-slate-300 dark:border-slate-700 px-3 py-1.5 text-sm hover:shadow-soft transition', '🌙 / ☀️');
  themeToggle.id = 'themeToggle';
  themeToggle.setAttribute('aria-label', 'Toggle dark mode');
  headerBtns.appendChild(vcardBtn);
  headerBtns.appendChild(themeToggle);
  header.appendChild(headerBtns);
  wrapper.appendChild(header);

  const mainCard = createAndStyleElement('main', 'fade-in rounded-3xl bg-white/80 dark:bg-slate-900/60 backdrop-blur shadow-soft ring-1 ring-slate-200/70 dark:ring-slate-800 p-6 md:p-8');
  const cardGrid = createAndStyleElement('div', 'grid grid-cols-1 md:grid-cols-5 gap-6 md:gap-8 items-start');

  const leftCol = createAndStyleElement('section', 'md:col-span-2 flex flex-col items-center gap-5');
  const avatarWrapper = createAndStyleElement('div', 'relative');
  const avatarImg = createAndStyleElement('img', 'h-40 w-40 md:h-48 md:w-48 rounded-2xl object-cover ring-2 ring-slate-200 dark:ring-slate-700 shadow');
  avatarImg.src = 'https://images.unsplash.com/photo-1502685104226-ee32379fefbe?q=80&w=500&auto=format&fit=crop';
  avatarImg.alt = 'Profile';
  const statusSpan = createAndStyleElement('span', 'absolute -bottom-2 -right-2 inline-flex items-center gap-1 rounded-full bg-emerald-600 text-white text-xs px-2 py-1 shadow');
  statusSpan.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="h-4 w-4"><path d="M12 6v6l4 2"/></svg>Available';
  avatarWrapper.appendChild(avatarImg);
  avatarWrapper.appendChild(statusSpan);
  leftCol.appendChild(avatarWrapper);

  const qrSection = createAndStyleElement('div', 'w-full');
  qrSection.appendChild(createAndStyleElement('h3', 'text-sm font-medium mb-2 opacity-80', 'Scan to open card'));
  const qrFlex = createAndStyleElement('div', 'flex items-center gap-3');
  const qrDiv = createAndStyleElement('div', 'rounded-xl p-3 bg-white dark:bg-slate-800 ring-1 ring-slate-200 dark:ring-slate-700');
  qrDiv.id = 'qrcode';
  const downloadQRBtn = createAndStyleElement('button', 'text-sm underline link-underline', 'Download QR');
  downloadQRBtn.id = 'downloadQR';
  qrFlex.appendChild(qrDiv);
  qrFlex.appendChild(downloadQRBtn);
  qrSection.appendChild(qrFlex);
  leftCol.appendChild(qrSection);
  cardGrid.appendChild(leftCol);

  const rightCol = createAndStyleElement('section', 'md:col-span-3 flex flex-col gap-5');
  const headerDetails = createAndStyleElement('header');
  headerDetails.appendChild(createAndStyleElement('h1', 'text-2xl sm:text-3xl md:text-4xl font-semibold leading-tight', 'Venkat'));
  headerDetails.appendChild(createAndStyleElement('p', 'text-base md:text-lg opacity-80', 'Frontend Developer • UI/UX Enthusiast'));
  rightCol.appendChild(headerDetails);

  rightCol.appendChild(createAndStyleElement('p', 'text-sm md:text-base leading-relaxed', 'I craft sleek, accessible web experiences with a focus on performance and delightful micro‑interactions. Currently building with React, TypeScript, and Tailwind.'));

  const contactGrid = createAndStyleElement('div', 'grid grid-cols-1 sm:grid-cols-2 gap-3');
  const phoneLink = createAndStyleElement('a', 'group rounded-xl border border-slate-200 dark:border-slate-800 p-3 hover:-translate-y-0.5 hover:shadow-soft transition');
  phoneLink.href = 'tel:+1234567890';
  phoneLink.innerHTML = '<div class="flex items-center gap-3"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="h-5 w-5 opacity-70 group-hover:opacity-100 transition"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.86 19.86 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6A19.86 19.86 0 0 1 2.09 4.18 2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.12.9.32 1.78.59 2.63a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.45-1.16a2 2 0 0 1 2.11-.45c.85.27 1.73.47 2.63.59A2 2 0 0 1 22 16.92z"/></svg><div><div class="text-xs uppercase tracking-wide opacity-60">Phone</div><div class="text-sm">+1 (234) 567‑890</div></div></div>';
  const emailLink = createAndStyleElement('a', 'group rounded-xl border border-slate-200 dark:border-slate-800 p-3 hover:-translate-y-0.5 hover:shadow-soft transition');
  emailLink.href = 'mailto:venkat@example.com';
  emailLink.innerHTML = '<div class="flex items-center gap-3"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="h-5 w-5 opacity-70 group-hover:opacity-100 transition"><path d="M4 4h16v16H4z"/><path d="m22 6-10 7L2 6"/></svg><div><div class="text-xs uppercase tracking-wide opacity-60">Email</div><div class="text-sm">venkat@example.com</div></div></div>';
  contactGrid.appendChild(phoneLink);
  contactGrid.appendChild(emailLink);
  rightCol.appendChild(contactGrid);

  const socialsDiv = createAndStyleElement('div', 'flex flex-wrap items-center gap-3');
  const socials = [
    { text: 'LinkedIn', href: 'https://www.linkedin.com/in/username' },
    { text: 'GitHub', href: 'https://github.com/username' },
    { text: 'Instagram', href: 'https://instagram.com/username' },
    { text: 'Portfolio', href: 'https://your-portfolio.example' }
  ];
  socials.forEach(s => {
    const link = createAndStyleElement('a', 'rounded-full ring-1 ring-slate-200 dark:ring-slate-800 px-3 py-1.5 text-sm hover:bg-slate-100 dark:hover:bg-slate-800 transition link-underline', s.text);
    link.href = s.href;
    link.target = '_blank';
    link.rel = 'noopener';
    socialsDiv.appendChild(link);
  });
  rightCol.appendChild(socialsDiv);

  const form = createAndStyleElement('form', 'mt-2 grid grid-cols-1 gap-3');
  form.name = 'contact';
  form.method = 'POST';
  form.setAttribute('data-netlify', 'true');
  form.setAttribute('netlify-honeypot', 'bot-field');
  form.innerHTML = `<input type="hidden" name="form-name" value="contact" /><p data-honeypot><label>Don’t fill this out if you’re human: <input name="bot-field" /></label></p><div class="grid grid-cols-1 sm:grid-cols-2 gap-3"><input required name="name" placeholder="Your name" class="rounded-xl border border-slate-300 dark:border-slate-700 bg-white/70 dark:bg-slate-900/60 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-emerald-500 transition" /><input required name="email" type="email" placeholder="Your email" class="rounded-xl border border-slate-300 dark:border-slate-700 bg-white/70 dark:bg-slate-900/60 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-emerald-500 transition" /></div><textarea required name="message" rows="4" placeholder="Message" class="rounded-xl border border-slate-300 dark:border-slate-700 bg-white/70 dark:bg-slate-900/60 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-emerald-500 transition"></textarea><div class="flex items-center gap-3"><button type="submit" class="rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2 transition shadow">Send</button><a href="mailto:venkat@example.com" class="text-sm underline link-underline">or email directly</a></div>`;
  rightCol.appendChild(form);
  cardGrid.appendChild(rightCol);
  mainCard.appendChild(cardGrid);
  wrapper.appendChild(mainCard);

  const footer = createAndStyleElement('footer', 'mt-6 text-center text-xs opacity-70');
  footer.innerHTML = `&copy; <span id="year"></span> Venkat · Built with HTML, Tailwind, and Vanilla JS`;
  wrapper.appendChild(footer);

  body.appendChild(wrapper);

  const script = document.createElement('script');
  script.textContent = `const html = document.documentElement;const themeToggle = document.getElementById('themeToggle');const storedTheme = localStorage.getItem('theme');if (storedTheme === 'dark' || (!storedTheme && window.matchMedia('(prefers-color-scheme: dark)').matches)) {html.classList.add('dark');}themeToggle.addEventListener('click', () => {html.classList.toggle('dark');localStorage.setItem('theme', html.classList.contains('dark') ? 'dark' : 'light');});const cardUrl = window.location.href;const qrContainer = document.getElementById('qrcode');const qr = new QRCode(qrContainer, {text: cardUrl,width: 110,height: 110,colorDark: '#111827',colorLight: '#ffffff',correctLevel: QRCode.CorrectLevel.M});document.getElementById('downloadQR').addEventListener('click', () => {const img = qrContainer.querySelector('img') || qrContainer.querySelector('canvas');if (!img) return;const link = document.createElement('a');link.download = 'business-card-qr.png';link.href = img.src || img.toDataURL();link.click();});document.getElementById('vcardBtn').addEventListener('click', () => {const vcard = ['BEGIN:VCARD','VERSION:3.0','N:Venkat;;;;','FN:Venkat','TITLE:Frontend Developer','EMAIL;TYPE=INTERNET;TYPE=WORK:venkat@example.com','TEL;TYPE=CELL:+1234567890',\`URL:\${cardUrl}\`,'ORG:Your Company','NOTE:Built with love and Tailwind','END:VCARD'].join('\\n');const blob = new Blob([vcard], { type: 'text/vcard;charset=utf-8' });const url = URL.createObjectURL(blob);const a = document.createElement('a');a.href = url;a.download = 'Venkat.vcf';document.body.appendChild(a);a.click();document.body.removeChild(a);URL.revokeObjectURL(url);});document.getElementById('year').textContent = new Date().getFullYear();`;
  body.appendChild(script);

  const qrScript = document.createElement('script');
  qrScript.src = 'https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js';
  qrScript.integrity = 'sha512-MmI2Z5y7uSXLXH5m0d5wV9YV1p6Fq1w0Q2kXxOwwlGkEoQDMp2H3bC4g5a9iE0j0zq+JgD9tJ+H1Qj1vZbq3Iw==';
  qrScript.crossOrigin = 'anonymous';
  qrScript.referrerPolicy = 'no-referrer';
  body.appendChild(qrScript);
}

createDigitalBusinessCard();